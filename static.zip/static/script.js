const form = document.getElementById('userForm');
const userTable = document.getElementById('userTable');
const nameInput = document.getElementById('name');
const emailInput = document.getElementById('email');
const userIdInput = document.getElementById('userId');

const fetchUsers = () => {
    fetch('/users')
        .then(res => res.json())
        .then(users => {
            userTable.innerHTML = '';
            users.forEach(user => {
                userTable.innerHTML += `
                    <tr>
                        <td>${user.id}</td>
                        <td>${user.name}</td>
                        <td>${user.email}</td>
                        <td>
                            <button onclick="editUser(${user.id}, '${user.name}', '${user.email}')" class="btn btn-sm btn-warning">Edit</button>
                            <button onclick="deleteUser(${user.id})" class="btn btn-sm btn-danger">Delete</button>
                        </td>
                    </tr>
                `;
            });
        });
};

const editUser = (id, name, email) => {
    userIdInput.value = id;
    nameInput.value = name;
    emailInput.value = email;
};

const deleteUser = (id) => {
    fetch(`/users/${id}`, { method: 'DELETE' })
        .then(() => fetchUsers());
};

form.onsubmit = (e) => {
    e.preventDefault();
    const id = userIdInput.value;
    const name = nameInput.value;
    const email = emailInput.value;
    const method = id ? 'PUT' : 'POST';
    const url = id ? `/users/${id}` : '/users';
    fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email })
    }).then(() => {
        form.reset();
        fetchUsers();
    });
};

fetchUsers();
